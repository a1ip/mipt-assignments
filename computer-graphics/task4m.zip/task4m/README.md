Drawing mosaics with a Voronoi diagram.

Run:
```
python -m SimpleHTTPServer
```
And then browse to http://127.0.0.1:8000/
